export enum Actions {
  ADD_USER = "ADD_USER",
  EDIT_USER = "EDIT_USER",
  DELETE_USER = "DELETE_USER"
}

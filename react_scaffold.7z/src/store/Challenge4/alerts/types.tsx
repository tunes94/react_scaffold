export enum Actions {
  ADD_ALERT = "ADD_ALERT",
  REMOVE_ALERT = "REMOVE_ALERT"
}

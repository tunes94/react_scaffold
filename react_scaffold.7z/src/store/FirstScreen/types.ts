/** define the available action of reducer */
export enum Actions{
    VALUE_CHANGED = 'VALUE_CHANGED',
    VALUE_DELETED = 'VALUE_DELETED'
}
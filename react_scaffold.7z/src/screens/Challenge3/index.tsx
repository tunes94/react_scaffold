import React from "react";

class Challenge3 extends React.Component {
  public render(): JSX.Element {
    return <h1>Challenge 3</h1>;
  }
}

export default Challenge3;

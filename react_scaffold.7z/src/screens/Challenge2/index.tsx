import React from "react";

class Challenge2 extends React.Component {
  public render(): JSX.Element {
    return <h1>Challenge 2</h1>;
  }
}

export default Challenge2;

import React from "react";

class Challenge1 extends React.Component {
  public render(): JSX.Element {
    return <h1>Challenge 1</h1>;
  }
}

export default Challenge1;

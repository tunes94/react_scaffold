import React from "react";

class Challenge4 extends React.Component {
  public render(): JSX.Element {
    return <h1>Challenge 4</h1>;
  }
}

export default Challenge4;
